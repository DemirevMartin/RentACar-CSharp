﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentACar_Copy
{
    public partial class Form_Tables : Form
    {
        public Form_Tables()
        {
            InitializeComponent();
        }

        private void label_Contracts_Click(object sender, EventArgs e)
        {
            Form_Contracts fcontr = new Form_Contracts();
            this.Hide();
            fcontr.ShowDialog();
            this.Show();
        }

        private void label_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label_Protocols_Click(object sender, EventArgs e)
        {
            Form_Protocols fp = new Form_Protocols();
            this.Hide();
            fp.ShowDialog();
            this.Show();
        }
    }
}
