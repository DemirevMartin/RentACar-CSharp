﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentACar_Copy
{
    public partial class RentACar : Form
    {
        public RentACar()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Form_Tables ft = new Form_Tables();
            this.Hide();
            ft.ShowDialog();
            this.Show();
        }
        private void label3_Click(object sender, EventArgs e)
        {
            Form_Queries fq = new Form_Queries();
            this.Hide();
            fq.ShowDialog();
            this.Show();
        }
        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void label4_Click_1(object sender, EventArgs e)
        {
            Form_Documentation fdoc = new Form_Documentation();
            this.Hide();
            fdoc.ShowDialog();
            this.Show();
        }
    }
}
