﻿
namespace RentACar_Copy
{
    partial class Form_Tables
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Vehicles = new System.Windows.Forms.Label();
            this.label_Categories = new System.Windows.Forms.Label();
            this.label_Customers = new System.Windows.Forms.Label();
            this.label_Protocols = new System.Windows.Forms.Label();
            this.label_Back = new System.Windows.Forms.Label();
            this.label_Contracts = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_Vehicles
            // 
            this.label_Vehicles.BackColor = System.Drawing.Color.Transparent;
            this.label_Vehicles.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Vehicles.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_Vehicles.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Vehicles.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Vehicles.Location = new System.Drawing.Point(73, 45);
            this.label_Vehicles.Name = "label_Vehicles";
            this.label_Vehicles.Size = new System.Drawing.Size(769, 85);
            this.label_Vehicles.TabIndex = 5;
            this.label_Vehicles.Text = "Vehicles";
            this.label_Vehicles.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Categories
            // 
            this.label_Categories.BackColor = System.Drawing.Color.Transparent;
            this.label_Categories.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Categories.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Categories.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Categories.Location = new System.Drawing.Point(73, 151);
            this.label_Categories.Name = "label_Categories";
            this.label_Categories.Size = new System.Drawing.Size(769, 85);
            this.label_Categories.TabIndex = 6;
            this.label_Categories.Text = "Categories";
            this.label_Categories.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Customers
            // 
            this.label_Customers.BackColor = System.Drawing.Color.Transparent;
            this.label_Customers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Customers.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Customers.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Customers.Location = new System.Drawing.Point(73, 256);
            this.label_Customers.Name = "label_Customers";
            this.label_Customers.Size = new System.Drawing.Size(769, 85);
            this.label_Customers.TabIndex = 7;
            this.label_Customers.Text = "Customers";
            this.label_Customers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Protocols
            // 
            this.label_Protocols.BackColor = System.Drawing.Color.Transparent;
            this.label_Protocols.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Protocols.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_Protocols.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Protocols.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Protocols.Location = new System.Drawing.Point(73, 467);
            this.label_Protocols.Name = "label_Protocols";
            this.label_Protocols.Size = new System.Drawing.Size(769, 85);
            this.label_Protocols.TabIndex = 8;
            this.label_Protocols.Text = "Protocols";
            this.label_Protocols.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Protocols.Click += new System.EventHandler(this.label_Protocols_Click);
            // 
            // label_Back
            // 
            this.label_Back.BackColor = System.Drawing.Color.Transparent;
            this.label_Back.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_Back.Font = new System.Drawing.Font("Bookman Old Style", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Back.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Back.Location = new System.Drawing.Point(475, 571);
            this.label_Back.Name = "label_Back";
            this.label_Back.Size = new System.Drawing.Size(367, 49);
            this.label_Back.TabIndex = 10;
            this.label_Back.Text = "Back";
            this.label_Back.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Back.Click += new System.EventHandler(this.label_Back_Click);
            // 
            // label_Contracts
            // 
            this.label_Contracts.BackColor = System.Drawing.Color.Transparent;
            this.label_Contracts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Contracts.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_Contracts.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Contracts.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Contracts.Location = new System.Drawing.Point(73, 361);
            this.label_Contracts.Name = "label_Contracts";
            this.label_Contracts.Size = new System.Drawing.Size(769, 85);
            this.label_Contracts.TabIndex = 11;
            this.label_Contracts.Text = "Contracts";
            this.label_Contracts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Contracts.Click += new System.EventHandler(this.label_Contracts_Click);
            // 
            // Form_Tables
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(30)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(914, 640);
            this.Controls.Add(this.label_Back);
            this.Controls.Add(this.label_Protocols);
            this.Controls.Add(this.label_Customers);
            this.Controls.Add(this.label_Categories);
            this.Controls.Add(this.label_Vehicles);
            this.Controls.Add(this.label_Contracts);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form_Tables";
            this.Text = "Tables";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_Vehicles;
        private System.Windows.Forms.Label label_Categories;
        private System.Windows.Forms.Label label_Customers;
        private System.Windows.Forms.Label label_Protocols;
        private System.Windows.Forms.Label label_Back;
        private System.Windows.Forms.Label label_Contracts;
    }
}