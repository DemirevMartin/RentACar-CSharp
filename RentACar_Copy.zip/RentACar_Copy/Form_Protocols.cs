﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;

namespace RentACar_Copy
{
    public partial class Form_Protocols : Form
    {
        public Form_Protocols()
        {
            InitializeComponent();
        }

        public void LoadData()
        {
            using (var context = new Rent4UDBContext())
            {
                dataGridView1.DataSource = context.Protocols
                    .Select(x => new
                    {
                        ContractID = x.ContractId,
                        ReturnDate = x.ReturnDate,
                        FinalMileage = x.FinishMileage
                    })
                    .OrderBy(x => x.ContractID)
                    .ToList();
            }
        }
        private void Form_Protocols_Load(object sender, EventArgs e)
        {
            this.LoadData();
        }

        /*private void button1_Click(object sender, EventArgs e)
        {
            Protocols_Add protocols_add = new Protocols_Add();
            this.Hide();
            protocols_add.ShowDialog();
            this.Show();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ByClick.ContractId = dataGridView1.CurrentRow.Cells["ContractId"].Value.ToString();

            Protocols_Edit protocols_edit = new Protocols_Edit();
            this.Hide();
            protocols_edit.ShowDialog();
            this.Show();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            ByClick.ContractId = dataGridView1.CurrentRow.Cells["ContractId"].Value.ToString();

            Protocols_Delete protocols_delete = new Protocols_Delete();
            this.Hide();
            protocols_delete.ShowDialog();
            this.Show();
        }*/
    }
}
