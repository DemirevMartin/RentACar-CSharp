﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;

namespace RentACar_Copy
{
    public partial class Query_FindVehicle : Form
    {
        public Query_FindVehicle()
        {
            InitializeComponent();
        }
        private void LoadData2()
        {
            string t = textBox1.Text;
            using (var ctx = new Rent4UDBContext())
            {
                var res = ctx.Vehicles
                    .Join(
                            ctx.Categories,
                            veh => veh.CategoryId,
                            categ => categ.CategoryId,
                            (veh, categ) => new
                            {
                                CarNumber = veh.CarNumber,
                                Rent = categ.Rent,
                                Type = categ.Type
                            }).Where(x => x.Type == t);

                dataGridView1.DataSource = res.ToList();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            LoadData2();
        }
    }
}
