﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentACar_Copy
{
    public partial class Form_Queries : Form
    {
        public Form_Queries()
        {
            InitializeComponent();
        }

        private void label_LastRents_Click(object sender, EventArgs e)
        {
            Query_Last10 ql = new Query_Last10();
            this.Hide();
            ql.ShowDialog();
            this.Show();
        }

        private void label_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label_AdvSum_Click(object sender, EventArgs e)
        {
            Query_AdvSumAndChange qasc = new Query_AdvSumAndChange();
            this.Hide();
            qasc.ShowDialog();
            this.Show();
        }

        private void label_FindVeh_Click(object sender, EventArgs e)
        {
            Query_FindVehicle qfh = new Query_FindVehicle();
            this.Hide();
            qfh.ShowDialog();
            this.Show();
        }

        private void label_Income_Click(object sender, EventArgs e)
        {
            Query_Income qi = new Query_Income();
            this.Hide();
            qi.ShowDialog();
            this.Show();
        }

        private void label_Mileage_Click(object sender, EventArgs e)
        {
            Query_Mileage qm = new Query_Mileage();
            this.Hide();
            qm.ShowDialog();
            this.Show();
        }

        private void Form_Queries_Load(object sender, EventArgs e)
        {
            
        }

        private void label_Rents_Click(object sender, EventArgs e)
        {
            Query_NumberOfRents qn = new Query_NumberOfRents();
            this.Hide();
            qn.ShowDialog();
            this.Show();

        }
    }
}
