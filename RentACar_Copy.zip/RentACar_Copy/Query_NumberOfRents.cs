﻿using RentACar_Copy.Models;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace RentACar_Copy
{
    public partial class Query_NumberOfRents : Form
    {
        public Query_NumberOfRents()
        {
            InitializeComponent();
        }

        private void Query_NumberOfRents_Load(object sender, EventArgs e)
        {
            using (var ctx = new Rent4UDBContext())
            {
                listBox1.DataSource = ctx.Vehicles.Select(x => x.CarNumber).ToList();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var ctx = new Rent4UDBContext())
            {

                var ch = listBox1.SelectedItem;

                var d = DateTime.Parse(dateTimePicker1.Text);

                var r = ctx.Contracts.Where(n => d > n.HireDate && n.CarNumber == ch)
                           .ToList();
                var rr = r.Count();
                var f = ctx.Contracts.Select(n => new
                {
                    CarNumber = n.CarNumber,
                    NumberOfRents = rr
                }).Where(n => n.CarNumber == ch)
                        .ToList();
                dataGridView1.DataSource = f;
            }
        }
    }
}