﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;

namespace RentACar_Copy
{
    public partial class Contracts_Delete : Form
    {
        Contract c;
        Rent4UDBContext context;
        public Contracts_Delete()
        {
            InitializeComponent();
        }

        private void Contracts_Delete_Load(object sender, EventArgs e)
        {
            context = new Rent4UDBContext();

            c = context.Contracts
                .Where(n => n.ContractId == ByClick.ContractId)
                .FirstOrDefault();
            textBox1.Text = c.ContractId;
            textBox2.Text = c.CustomerId.ToString();
            textBox3.Text = c.CarNumber;
            dateTimePicker1.Text = c.HireDate.ToString();
            textBox4.Text = c.StartMileage.ToString();
            textBox5.Text = c.Advance.ToString();

            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            dateTimePicker1.Enabled = false;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            c.ContractId = textBox1.Text;
            c.CustomerId = int.Parse(textBox2.Text);
            c.CarNumber = textBox3.Text;
            c.HireDate = DateTime.Parse(dateTimePicker1.Text);
            c.StartMileage = int.Parse(textBox4.Text);
            c.Advance = decimal.Parse(textBox5.Text);

            context.Contracts.Remove(c);
            context.SaveChanges();
            context.Dispose();
            MessageBox.Show("One record deleted from Customers!", "Success!");
        }
    }
}
