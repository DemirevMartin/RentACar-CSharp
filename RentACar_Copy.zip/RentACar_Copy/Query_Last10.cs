﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;

namespace RentACar_Copy
{
    public partial class Query_Last10 : Form
    {
        public Query_Last10()
        {
            InitializeComponent();
        }
        public void LoadData()
        {
            using (var context = new Rent4UDBContext())
            {
                dataGridView1.DataSource = context.Contracts
                    .Select(x => new
                    {
                        ContractID = x.ContractId,
                        CustomerID = x.CustomerId,
                        CarNumber = x.CarNumber,
                        HireDate = x.HireDate,
                        StartMileage = x.StartMileage,
                        Advance = x.Advance
                    })
                    .OrderByDescending(x => x.HireDate)
                    .Take(10)
                    .ToList();
            }
        }
        private void Query_Last10_Load(object sender, EventArgs e)
        {
            //SELECT TOP(10) *
            //FROM Contracts
            //ORDER BY HireDate DESC;

            this.LoadData();
        }
    }
}

