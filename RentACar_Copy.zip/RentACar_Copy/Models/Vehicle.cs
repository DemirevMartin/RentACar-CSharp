﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RentACar_Copy.Models
{
    public partial class Vehicle
    {
        public Vehicle()
        {
            Contracts = new HashSet<Contract>();
        }

        public string CarNumber { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int CategoryId { get; set; }
        public float PricePerKm { get; set; }

        public virtual Category Category { get; set; }
        public virtual ICollection<Contract> Contracts { get; set; }
    }
}
