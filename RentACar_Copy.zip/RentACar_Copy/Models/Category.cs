﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RentACar_Copy.Models
{
    public partial class Category
    {
        public Category()
        {
            Vehicles = new HashSet<Vehicle>();
        }

        public int CategoryId { get; set; }
        public string Type { get; set; }
        public decimal Rent { get; set; }

        public virtual ICollection<Vehicle> Vehicles { get; set; }
    }
}
