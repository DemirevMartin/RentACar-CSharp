﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RentACar_Copy.Models
{
    public partial class Contract
    {
        public string ContractId { get; set; }
        public int CustomerId { get; set; }
        public string CarNumber { get; set; }
        public DateTime HireDate { get; set; }
        public int StartMileage { get; set; }
        public decimal Advance { get; set; }

        public virtual Vehicle CarNumberNavigation { get; set; }
        public virtual Customer Customer { get; set; }
    }
}
