﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RentACar_Copy.Models
{
    public partial class Protocol
    {
        public string ContractId { get; set; }
        public DateTime ReturnDate { get; set; }
        public int FinishMileage { get; set; }

        public virtual Contract Contract { get; set; }
    }
}
