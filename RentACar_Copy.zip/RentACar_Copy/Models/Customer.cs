﻿using System;
using System.Collections.Generic;

#nullable disable

namespace RentACar_Copy.Models
{
    public partial class Customer
    {
        public Customer()
        {
            Contracts = new HashSet<Contract>();
        }

        public int CustomerId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public bool Company { get; set; }
        public string PhoneNumber { get; set; }

        public virtual ICollection<Contract> Contracts { get; set; }
    }
}
