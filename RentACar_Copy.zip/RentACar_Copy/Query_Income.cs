﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;

namespace RentACar_Copy
{
    public partial class Query_Income : Form
    {
        public Query_Income()
        {
            InitializeComponent();
        }

        private void Query_Income_Load(object sender, EventArgs e)
        {
            using (var ctx = new Rent4UDBContext())
            {
                dataGridView1.DataSource = ctx.Vehicles.Join(
                    ctx.Categories,
                    veh => veh.CategoryId,
                    categ => categ.CategoryId,
                    (veh, categ) => new
                    {
                        Rent = categ.Rent,
                        Type = categ.Type,
                        PricePerKm = veh.PricePerKm,
                        CarNumber = veh.CarNumber
                    })
                    .Join(ctx.Contracts,
                    x => x.CarNumber,
                    y => y.CarNumber,
                    (x, y) => new
                    {
                        Rent = x.Rent,
                        PricePerKm = x.PricePerKm,
                        CarNumber = x.CarNumber,
                        Type = x.Type,
                        HireDate = y.HireDate,
                        ContractId = y.ContractId,
                        StartMileage = y.StartMileage,
                        CustomerId = y.CustomerId
                    })
                    .Join(ctx.Protocols,
                    x => x.ContractId,
                    y => y.ContractId,
                    (x, y) => new
                    {
                        Rent = x.Rent,
                        PricePerKm = x.PricePerKm,
                        CarNumber = x.CarNumber,
                        HireDate = x.HireDate,
                        Type = x.Type,
                        ContractId = x.ContractId,
                        StartMileage = x.StartMileage,
                        ReturnDate = y.ReturnDate,
                        CustomerId = x.CustomerId,
                        FinishMileage = y.FinishMileage
                    })
                    .Join(ctx.Customers,
                    x => x.CustomerId,
                    y => y.CustomerId,
                    (x, y) => new
                    {
                        Type = x.Type,
                        Rent = x.Rent,
                        PricePerKm = x.PricePerKm,
                        CarNumber = x.CarNumber,
                        HireDate = x.HireDate,
                        ContractId = x.ContractId,
                        StartMileage = x.StartMileage,
                        ReturnDate = x.ReturnDate,
                        CustomerId = x.CustomerId,
                        FinishMileage = x.FinishMileage,
                        Company = y.Company
                    })
                    .Select(x => new
                    {
                        CarNumber = x.CarNumber,
                        Income = (decimal)((x.ReturnDate - x.HireDate).TotalDays) * x.Rent + (x.FinishMileage - x.StartMileage) * (int)x.PricePerKm
                    })
                    .ToList();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
