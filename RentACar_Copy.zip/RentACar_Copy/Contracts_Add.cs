﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;
using Microsoft.EntityFrameworkCore;

namespace RentACar_Copy
{
    public partial class Contracts_Add : Form
    {
        Rent4UDBContext context = new Rent4UDBContext();
        public Contracts_Add()
        {
            InitializeComponent();
        }

        private string EditID()
        {
            var all = context.Contracts
                .OrderByDescending(x => x.ContractId)
                .Select(x => x.ContractId)
                .ToList();
            string last = Convert.ToString(all[0]);

            int counterZero = 0;
            int num = 0;
            string output = Convert.ToString(last[0]) + Convert.ToString(last[1]);
            for (int i = 2; i < last.Length; i++)
            {
                int current = last[i] - '0';
                if (current != 0)
                {
                    num = int.Parse(last.Substring(i, last.Length - i)) + 1;
                    break;
                }
                counterZero++;
            }

            output += new String('0', counterZero) + Convert.ToString(num);
            return output;
        }
        private void Contracts_Add_Load(object sender, EventArgs e)
        {
            using (var rc = new Rent4UDBContext())
            {
                comboBox1.DataSource = rc.Customers
                    .Select(x => new { x.CustomerId })
                    .OrderBy(x => x.CustomerId)
                    .ToList();
                comboBox1.DisplayMember = "Name";
                comboBox1.ValueMember = "CustomerID";
                comboBox1.SelectedIndex = 0;

                comboBox2.DataSource = rc.Vehicles
                     .Select(x => new { x.CarNumber })
                     .ToList();
                comboBox2.DisplayMember = "Number";
                comboBox2.ValueMember = "CarNumber";
                comboBox2.SelectedIndex = 0;
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var rc = new Rent4UDBContext())
            {
                Contract c = new Contract()
                {
                    ContractId = EditID(),
                    HireDate = DateTime.Parse(dateTimePicker1.Text),
                    StartMileage = int.Parse(textBox4.Text),
                    Advance = decimal.Parse(textBox5.Text)
                };

                int ct = (int)comboBox1.SelectedValue;
                c.CustomerId = ct;
                string v = (string)comboBox2.SelectedValue;
                c.CarNumber = v;

                rc.Contracts.Add(c);
                rc.SaveChanges();
                MessageBox.Show("One record added to Contracts!", "Success!");

                textBox4.Text = "";
                textBox5.Text = "";
                dateTimePicker1.Text = "";
                comboBox1.SelectedIndex = 0;
                comboBox2.SelectedIndex = 0;
            }
        }

    }
}
