﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;

namespace RentACar_Copy
{
    public partial class Form_Contracts : Form
    {
        public Form_Contracts()
        {
            InitializeComponent();
        }
        public void LoadData()
        {
            using (var context = new Rent4UDBContext())
            {
                dataGridView1.DataSource = context.Contracts
                    .Select(x => new
                    {
                        ContractID = x.ContractId,
                        CustomerID = x.CustomerId,
                        CarNumber = x.CarNumber,
                        HireDate = x.HireDate,
                        StartMileage = x.StartMileage,
                        Advance = x.Advance
                    })
                    .OrderBy(x => x.ContractID)
                    .ToList();
            }
        }
        private void Form_Contracts_Load(object sender, EventArgs e)
        {
            this.LoadData();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Contracts_Add contracts_add = new Contracts_Add();
            this.Hide();
            contracts_add.ShowDialog();
            this.LoadData();
            this.Show();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ByClick.ContractId = dataGridView1.CurrentRow.Cells["ContractId"].Value.ToString();

            Contracts_Edit contracts_edit = new Contracts_Edit();
            this.Hide();
            contracts_edit.ShowDialog();
            this.LoadData();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ByClick.ContractId = dataGridView1.CurrentRow.Cells["ContractId"].Value.ToString();

            Contracts_Delete contracts_delete = new Contracts_Delete();
            this.Hide();
            contracts_delete.ShowDialog();
            this.LoadData();
            this.Show();
        }
    }
}
