﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACar_Copy
{
    internal class ByClick
    {
        public static string CarNumber;
        public static int CategoryId;
        public static int CustomerId;
        public static string ContractId;
    }
}
