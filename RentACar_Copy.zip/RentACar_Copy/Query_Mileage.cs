﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;

namespace RentACar_Copy
{
    public partial class Query_Mileage : Form
    {
        public Query_Mileage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var ctx = new Rent4UDBContext())
            {

                var ch = listBox1.SelectedItem;
                var res = ctx.Vehicles.Join(
                    ctx.Contracts,
                    veh => veh.CarNumber,
                    contr => contr.CarNumber,
                    (veh, contr) => new
                    {
                        ContractId = contr.ContractId,
                        CarNumber = contr.CarNumber
                    })
                    .Where(x => x.CarNumber == ch)
                    .Join(ctx.Protocols,
                    x => x.ContractId,
                    y => y.ContractId,
                    (x, y) => new
                    {

                        CarNumber = x.CarNumber,
                        ReturnDate = y.ReturnDate,
                        FinishMileage = y.FinishMileage
                    })
                    .OrderByDescending(x => x.ReturnDate)
                    .Take(1)
                    .Select(x => new
                    {
                        CarNumber = x.CarNumber,
                        FinishMileage = x.FinishMileage
                    })
                    .ToList();


                dataGridView1.DataSource = res.ToList();


            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Query_Mileage_Load(object sender, EventArgs e)
        {
            using (var ctx = new Rent4UDBContext())
            {
                listBox1.DataSource = ctx.Vehicles.Select(x => x.CarNumber).ToList();


            }
        }
    }
}
