﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;
using Microsoft.EntityFrameworkCore;

namespace RentACar_Copy
{
    public partial class Contracts_Edit : Form
    {
        Rent4UDBContext context;
        Contract contract;
        public Contracts_Edit()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            contract.ContractId = textBox1.Text;
            contract.CustomerId = int.Parse(comboBox1.Text);
            contract.CarNumber = comboBox2.Text;
            contract.HireDate = DateTime.Parse(dateTimePicker1.Text);
            contract.StartMileage = int.Parse(textBox5.Text);
            contract.Advance = decimal.Parse(textBox4.Text);
            context.SaveChanges();
            context.Dispose();
            MessageBox.Show("The data is successfully edited!", "Edit complete!");
        }
        private void Contracts_Edit_Load(object sender, EventArgs e)
        {
            context = new Rent4UDBContext();

            contract = context.Contracts
                .Where(n => n.ContractId == ByClick.ContractId)
                .FirstOrDefault();

            comboBox1.DataSource = context.Customers
                .Select(x => new { x.CustomerId })
                .OrderBy(x => x.CustomerId)
                .ToList();
            comboBox1.DisplayMember = "Customer";
            comboBox1.ValueMember = "CustomerId";
            comboBox1.SelectedIndex = 0;

            comboBox2.DataSource = context.Vehicles
                .Select(x => new { x.CarNumber })
                .OrderBy(x => x.CarNumber)
                .ToList();
            comboBox2.DisplayMember = "Vehicle";
            comboBox2.ValueMember = "CarNumber";
            comboBox2.SelectedIndex = 0;

            textBox1.Text = contract.ContractId.ToString();
            comboBox1.Text = contract.CustomerId.ToString();
            comboBox2.Text = contract.CarNumber;
            dateTimePicker1.Text = contract.HireDate.ToString();
            textBox5.Text = contract.StartMileage.ToString();
            textBox4.Text = contract.Advance.ToString();
        }

        
    }
}
