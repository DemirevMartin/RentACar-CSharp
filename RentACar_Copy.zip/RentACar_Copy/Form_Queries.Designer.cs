﻿
namespace RentACar_Copy
{
    partial class Form_Queries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_FindVeh = new System.Windows.Forms.Label();
            this.label_Mileage = new System.Windows.Forms.Label();
            this.label_Income = new System.Windows.Forms.Label();
            this.label_AdvSum = new System.Windows.Forms.Label();
            this.label_Rents = new System.Windows.Forms.Label();
            this.label_Back = new System.Windows.Forms.Label();
            this.label_LastRents = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_FindVeh
            // 
            this.label_FindVeh.BackColor = System.Drawing.Color.Transparent;
            this.label_FindVeh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_FindVeh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_FindVeh.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_FindVeh.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_FindVeh.Location = new System.Drawing.Point(64, 34);
            this.label_FindVeh.Name = "label_FindVeh";
            this.label_FindVeh.Size = new System.Drawing.Size(673, 64);
            this.label_FindVeh.TabIndex = 5;
            this.label_FindVeh.Text = "Find vehicle";
            this.label_FindVeh.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_FindVeh.Click += new System.EventHandler(this.label_FindVeh_Click);
            // 
            // label_Mileage
            // 
            this.label_Mileage.BackColor = System.Drawing.Color.Transparent;
            this.label_Mileage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Mileage.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Mileage.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Mileage.Location = new System.Drawing.Point(64, 113);
            this.label_Mileage.Name = "label_Mileage";
            this.label_Mileage.Size = new System.Drawing.Size(673, 64);
            this.label_Mileage.TabIndex = 6;
            this.label_Mileage.Text = "Mileage for each vehicle";
            this.label_Mileage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Mileage.Click += new System.EventHandler(this.label_Mileage_Click);
            // 
            // label_Income
            // 
            this.label_Income.BackColor = System.Drawing.Color.Transparent;
            this.label_Income.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Income.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Income.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Income.Location = new System.Drawing.Point(64, 192);
            this.label_Income.Name = "label_Income";
            this.label_Income.Size = new System.Drawing.Size(673, 64);
            this.label_Income.TabIndex = 7;
            this.label_Income.Text = "Income";
            this.label_Income.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Income.Click += new System.EventHandler(this.label_Income_Click);
            // 
            // label_AdvSum
            // 
            this.label_AdvSum.BackColor = System.Drawing.Color.Transparent;
            this.label_AdvSum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_AdvSum.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_AdvSum.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_AdvSum.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_AdvSum.Location = new System.Drawing.Point(64, 271);
            this.label_AdvSum.Name = "label_AdvSum";
            this.label_AdvSum.Size = new System.Drawing.Size(673, 64);
            this.label_AdvSum.TabIndex = 8;
            this.label_AdvSum.Text = "Advance sum and change";
            this.label_AdvSum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_AdvSum.Click += new System.EventHandler(this.label_AdvSum_Click);
            // 
            // label_Rents
            // 
            this.label_Rents.BackColor = System.Drawing.Color.Transparent;
            this.label_Rents.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Rents.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_Rents.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Rents.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Rents.Location = new System.Drawing.Point(64, 350);
            this.label_Rents.Name = "label_Rents";
            this.label_Rents.Size = new System.Drawing.Size(673, 64);
            this.label_Rents.TabIndex = 9;
            this.label_Rents.Text = "Number of rents per vehicle for a period";
            this.label_Rents.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Rents.Click += new System.EventHandler(this.label_Rents_Click);
            // 
            // label_Back
            // 
            this.label_Back.BackColor = System.Drawing.Color.Transparent;
            this.label_Back.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_Back.Font = new System.Drawing.Font("Bookman Old Style", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_Back.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_Back.Location = new System.Drawing.Point(416, 509);
            this.label_Back.Name = "label_Back";
            this.label_Back.Size = new System.Drawing.Size(321, 37);
            this.label_Back.TabIndex = 10;
            this.label_Back.Text = "Back";
            this.label_Back.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Back.Click += new System.EventHandler(this.label_Back_Click);
            // 
            // label_LastRents
            // 
            this.label_LastRents.BackColor = System.Drawing.Color.Transparent;
            this.label_LastRents.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_LastRents.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_LastRents.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label_LastRents.ForeColor = System.Drawing.Color.Gainsboro;
            this.label_LastRents.Location = new System.Drawing.Point(64, 430);
            this.label_LastRents.Name = "label_LastRents";
            this.label_LastRents.Size = new System.Drawing.Size(673, 64);
            this.label_LastRents.TabIndex = 11;
            this.label_LastRents.Text = "Last 10 rents";
            this.label_LastRents.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_LastRents.Click += new System.EventHandler(this.label_LastRents_Click);
            // 
            // Form_Queries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(30)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(800, 562);
            this.Controls.Add(this.label_Back);
            this.Controls.Add(this.label_Rents);
            this.Controls.Add(this.label_AdvSum);
            this.Controls.Add(this.label_Income);
            this.Controls.Add(this.label_Mileage);
            this.Controls.Add(this.label_FindVeh);
            this.Controls.Add(this.label_LastRents);
            this.MaximizeBox = false;
            this.Name = "Form_Queries";
            this.Text = "Query_AdvSumAndChange";
            this.Load += new System.EventHandler(this.Form_Queries_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_FindVeh;
        private System.Windows.Forms.Label label_Mileage;
        private System.Windows.Forms.Label label_Income;
        private System.Windows.Forms.Label label_AdvSum;
        private System.Windows.Forms.Label label_Rents;
        private System.Windows.Forms.Label label_Back;
        private System.Windows.Forms.Label label_LastRents;
    }
}