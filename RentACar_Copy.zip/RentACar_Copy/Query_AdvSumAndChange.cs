﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RentACar_Copy.Models;

namespace RentACar_Copy
{
    public partial class Query_AdvSumAndChange : Form
    {
        public Query_AdvSumAndChange()
        {
            InitializeComponent();
        }
        public void LoadData()
        {
            using (var context = new Rent4UDBContext())
            {
                dataGridView1.DataSource = context.Contracts
                    .Select(x => new
                    {
                        ContractID = x.ContractId,
                        HireDate = x.HireDate,
                        StartMileage = x.StartMileage,
                        Advance = x.Advance,
                        Change = Math.Round(((Math.Round((decimal) (x.StartMileage * 0.00176), 1)
                            * ((int) (DateTime.Now - x.HireDate).TotalDays) - x.Advance) * (decimal) 0.004), 2)
                    })
                    .OrderBy(x => x.ContractID)
                    .ToList();
            }
        }
        private void Query_AdvSumAndChange_Load(object sender, EventArgs e)
        {
            this.LoadData();
        }
    }
}
